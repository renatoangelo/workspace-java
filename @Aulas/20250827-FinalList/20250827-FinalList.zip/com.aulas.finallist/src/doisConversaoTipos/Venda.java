package doisConversaoTipos;

public class Venda {
    private String valor;

    public Venda(String valor) {
        this.valor = valor;
    }

    public String getValor() {
        return valor;
    }
}
